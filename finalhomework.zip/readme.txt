1. Download the .zip file
2. go to your C: drive in File Explorer
3. extract the contents of the .zip
4. Open the Finalhomework.py program in the Finalhomework folder, and this will get things running

Once you are in this program, you will operate from Top Down.

First, you will enter your Name, the Address you want the food delivered to, and then your Phone number
       Note! All three fields must be enterred into. Your name must be between 1 to 25 Characters, address is between 3 to 25, and your Phone 
                Number must be 10 digits
Second, you will click any of the 5 toppings that you want on your pizza, and select the "Add the selected toppings to your pizza" box. 
 Note *you can highlight an item in that blue list, and hit "Remove Selection" to take it off of the list
Third, click the "Finalize Order" button, to complete your order. (Note * If you address does not look correct, hit the corresponding button to go back)
         Finish your order, and the program will close







Notes on the Source Code
The main code runs throughout the program, and certain functions are broken up modularly, such as the add_pizza function, or the 
openWindow function, which break down the code even further, to simplify things




##Credits for Images
#flaticon.com/free-sticker/pizza-slice_4910034# - Image of Pizza in top right corner
#https://iconarchive.com/show/swarm-icons-by-sonya/Pizza-icon.html Pizza Icon
#Shopping Cart Icon https://findicons.com/icon/download/50149/shopping_cart/128/ico
#https://www.pngitem.com/middle/ihRwTJR_pizza-delivery-car-png-transparent-png/ Delivery truck image
